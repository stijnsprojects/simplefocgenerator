1) Double click setup and click install.
2) The application is installed, you can delete this folder.
3) Run the application from start

To uninstall, use the control panel.