These are the source files of the SimpleFOCGenerator for offline use, open index.html using any browser or open the online version:

https://stijnsprojects.github.io/simplefocgenerator/
